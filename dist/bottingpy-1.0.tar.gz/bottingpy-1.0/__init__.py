__name__ = 'bottingpy'
__description__ = 'Creating bots for you!'
__version__ = '1.0'
__company__ = 'Xgame'
__github__ = 'https://github.com/itttgg/botting_py'

import bottingpy.chat
import bottingpy.function